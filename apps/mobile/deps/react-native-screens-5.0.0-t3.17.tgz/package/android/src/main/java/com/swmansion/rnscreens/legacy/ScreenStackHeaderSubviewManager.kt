package com.swmansion.rnscreens.legacy

import android.util.Log
import com.facebook.react.bridge.JSApplicationIllegalArgumentException
import com.facebook.react.module.annotations.ReactModule
import com.facebook.react.uimanager.ReactStylesDiffMap
import com.facebook.react.uimanager.StateWrapper
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.ViewGroupManager
import com.facebook.react.uimanager.ViewManagerDelegate
import com.facebook.react.viewmanagers.RNSScreenStackHeaderSubviewManagerDelegate
import com.facebook.react.viewmanagers.RNSScreenStackHeaderSubviewManagerInterface

@ReactModule(name = ScreenStackHeaderSubviewManager.REACT_CLASS)
class ScreenStackHeaderSubviewManager :
    ViewGroupManager<ScreenStackHeaderSubview>(),
    RNSScreenStackHeaderSubviewManagerInterface<ScreenStackHeaderSubview> {
    private val delegate: ViewManagerDelegate<ScreenStackHeaderSubview>

    init {
        delegate = RNSScreenStackHeaderSubviewManagerDelegate<ScreenStackHeaderSubview, ScreenStackHeaderSubviewManager>(this)
    }

    override fun getName() = REACT_CLASS

    override fun createViewInstance(context: ThemedReactContext) = ScreenStackHeaderSubview(context)

    override fun setType(
        view: ScreenStackHeaderSubview,
        type: String?,
    ) {
        view.type =
            when (type) {
                "left" -> ScreenStackHeaderSubview.Type.LEFT
                "center" -> ScreenStackHeaderSubview.Type.CENTER
                "right" -> ScreenStackHeaderSubview.Type.RIGHT
                "back" -> ScreenStackHeaderSubview.Type.BACK
                "searchBar" -> ScreenStackHeaderSubview.Type.SEARCH_BAR
                else -> throw JSApplicationIllegalArgumentException("Unknown type $type")
            }
    }

    override fun setHidesSharedBackground(
        view: ScreenStackHeaderSubview,
        hidesSharedBackground: Boolean,
    ) {
        Log.w("[RNScreens]", "hidesSharedBackground prop is not available on Android")
    }

    // Bar button transition identifiers only apply on iOS.
    override fun setIdentifier(
        view: ScreenStackHeaderSubview,
        identifier: String?,
    ) = Unit
    override fun setVisibilityPriority(
        view: ScreenStackHeaderSubview,
        visibilityPriority: String?,
    ) {
        Log.w("[RNScreens]", "visibilityPriority prop is not available on Android")
    }

    // synchronousShadowStateUpdatesEnabled is not available on Android atm,
    // however we must override their setters
    override fun setSynchronousShadowStateUpdatesEnabled(
        view: ScreenStackHeaderSubview?,
        value: Boolean,
    ) = Unit

    override fun updateState(
        view: ScreenStackHeaderSubview,
        props: ReactStylesDiffMap?,
        stateWrapper: StateWrapper?,
    ): Any? {
        view.setStateWrapper(stateWrapper)
        return super.updateState(view, props, stateWrapper)
    }

    protected override fun getDelegate(): ViewManagerDelegate<ScreenStackHeaderSubview> = delegate

    companion object {
        const val REACT_CLASS = "RNSScreenStackHeaderSubview"
    }
}
