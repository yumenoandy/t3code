package com.swmansion.rnscreens.core.modals.formsheet.presentation

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ValueAnimator
import android.view.View

internal class FormSheetAnimatorFactory(
    private val dimmingManager: FormSheetDimmingManager,
) {
    // TODO: @t0maboro - consider exposing as a prop
    val animationDuration = 250L

    internal fun createEnterAnimator(
        view: View,
        isInterrupting: Boolean = false,
    ): Animator {
        val startY = if (isInterrupting) view.translationY else view.height.toFloat()
        val startAlpha = if (isInterrupting) dimmingManager.dimmingAlpha else 0f

        val slideAnimator =
            ValueAnimator.ofFloat(startY, 0f).apply {
                addUpdateListener { animation ->
                    view.translationY = animation.animatedValue as Float
                }
            }

        val alphaAnimator =
            ValueAnimator.ofFloat(startAlpha, dimmingManager.maxAlpha).apply {
                addUpdateListener { animation ->
                    dimmingManager.dimmingAlpha = animation.animatedValue as Float
                }
            }

        return AnimatorSet().apply {
            playTogether(slideAnimator, alphaAnimator)
            duration = animationDuration
        }
    }

    internal fun createExitAnimator(
        view: View,
        isInterrupting: Boolean = false,
    ): Animator {
        // Always leave from the current translation: besides an interrupted enter animation, the sheet
        // may be mid-way through tracking the keyboard animation when the dismissal starts.
        val startY = view.translationY
        val startAlpha = if (isInterrupting) dimmingManager.dimmingAlpha else dimmingManager.maxAlpha

        val slideAnimator =
            ValueAnimator.ofFloat(startY, view.height.toFloat()).apply {
                addUpdateListener { animation ->
                    view.translationY = animation.animatedValue as Float
                }
            }

        val alphaAnimator =
            ValueAnimator.ofFloat(startAlpha, 0f).apply {
                addUpdateListener { animation ->
                    dimmingManager.dimmingAlpha = animation.animatedValue as Float
                }
            }

        return AnimatorSet().apply {
            playTogether(slideAnimator, alphaAnimator)
            duration = animationDuration
        }
    }
}
